
public abstract class CharacterFactory {
	protected abstract DungeonCharacter makeChar();
}
