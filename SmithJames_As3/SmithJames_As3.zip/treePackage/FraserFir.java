package treePackage;

public class FraserFir extends Tree{
	public FraserFir()
	{
		this.setDescription("Fraser Fir tree decorated with");
	}
	public double cost()
	{
		return 35;
	}
}
