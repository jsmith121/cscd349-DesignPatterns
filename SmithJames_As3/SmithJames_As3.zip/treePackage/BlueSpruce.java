package treePackage;

public class BlueSpruce extends Tree{

	public BlueSpruce()
	{	
		this.setDescription("Blue Spruce tree decorated with");		
	}
	public double cost()
	{
		return 50;
	}
}
