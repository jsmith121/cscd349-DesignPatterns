package treePackage;

public class DouglasFir extends Tree{
	public DouglasFir()
	{
		this.setDescription("Douglas Fir tree decorated with");
	}
	public double cost()
	{
		return 30;
	}
}
