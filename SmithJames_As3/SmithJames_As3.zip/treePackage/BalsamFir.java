package treePackage;

public class BalsamFir extends Tree {
	public BalsamFir()
	{
		this.setDescription("Balsam Fir tree decorated with");
	}
	public double cost()
	{
		return 25;
	}
}
